#include <iostream>
#include <vector>
#include "Utils.h"
#include "CImg.h"

using namespace cimg_library;

/*
* Reisiganan Ambikapathy (AMB19705060) - CMP3752M
* 
This project is written using localised ID for the parallel implementation of outputting images.
The intensity histogram, cumulative histogram and normalised cumulative histogram uses Hillis Stelle, for a successful scan operation run in parralel optimisation. 
The inclusive scan is made to require two additional input arguments that correspond accordingly with two buffers that run locally.
Scratch was used within the kernel as a local buffer to used to insert global memory on a temporary basis.

* Globalised Hillis Stelle scan were implemented for intensity histogram and cumulative histogram outputs
* Localised Hillis stelle for normalised cumulative histogram output

Flexible step reduce scan was implented within the kernels however not used within the cpp file . The i replicates the stride.
The modulo operator was utilised to skip a set of values  within kernel fixed_reduceAdd, prior to ensuring the elements are added within bounds
Flexible step reduce 2,3 and 4 were implemented to reduct the local memory with the implementation of local sums in a single locaion 


The HistScanAdjust was implemented to be stored in partial scans when adding block sums to its relevant blocks
The hist_scanAtomic was utilissed to localising histogram through setting bin index

The profiling of queue have been impleneted to display the execution times for each of the histogram.

Buffers and kernels are created to display the array of values during the conversion from input to output image.

The code perfectly works when run on both colour and greyscale in 8 bit representation



*/

void print_help() {
	std::cerr << "Application usage:" << std::endl;

	std::cerr << "  -p : select platform " << std::endl;
	std::cerr << "  -d : select device" << std::endl;
	std::cerr << "  -l : list all platforms and devices" << std::endl;
	std::cerr << "  -f : input image file (default: test.ppm)" << std::endl;
	std::cerr << "  -h : print this message" << std::endl;
}

int main(int argc, char** argv) {

	int platform_id = 0;
	int device_id = 0;
	string image_filename = "test.pgm";

	for (int i = 1; i < argc; i++) {
		if ((strcmp(argv[i], "-p") == 0) && (i < (argc - 1))) { platform_id = atoi(argv[++i]); }
		else if ((strcmp(argv[i], "-d") == 0) && (i < (argc - 1))) { device_id = atoi(argv[++i]); }
		else if (strcmp(argv[i], "-l") == 0) { std::cout << ListPlatformsDevices() << std::endl; }
		else if ((strcmp(argv[i], "-f") == 0) && (i < (argc - 1))) { image_filename = argv[++i]; }
		else if (strcmp(argv[i], "-h") == 0) { print_help(); return 0; }
	}

	cimg::exception_mode(0);

	try {
		CImg<unsigned char> image_input(image_filename.c_str());
		CImgDisplay disp_input(image_input, "input");


		//Part 3 - host operations
		//3.1 Select computing devices by initializing context
		cl::Context context = GetContext(platform_id, device_id);

		//display the selected device
		std::cout << "Runing on " << GetPlatformName(platform_id) << ", " << GetDeviceName(platform_id, device_id) << std::endl;

		//Create a queue that will output the execution times for each histogram
		cl::CommandQueue queue(context, CL_QUEUE_PROFILING_ENABLE);//Enable Profiling for the queue
		cl::Event prof_event;// //Profiling queue for intensity histogram
		cl::Event prof_event2; //Profiling queue for cumulative histogram  
		cl::Event prof_event3; //normalised cumulative histogram
		cl::Event prof_event4; //LUT 

		//3.2 Load & build the device code
		cl::Program::Sources sources;
		AddSources(sources, "kernels/my_kernels.cl");//extract the kernel code
		cl::Program program(context, sources);

		//Build and debug the kernel code
		try {
			program.build();
		}
		catch (const cl::Error& err) {
			std::cout << "Build Status: " << program.getBuildInfo<CL_PROGRAM_BUILD_STATUS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Options:\t" << program.getBuildInfo<CL_PROGRAM_BUILD_OPTIONS>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			std::cout << "Build Log:\t " << program.getBuildInfo<CL_PROGRAM_BUILD_LOG>(context.getInfo<CL_CONTEXT_DEVICES>()[0]) << std::endl;
			throw err;
		}

		
		vector<int> H(256, 0);//create a variable to process vector_Size by  vector H size (256) times the int size 
		size_t vector_Size = H.size() * sizeof(int); //size in bytes
		vector<int> CH(256, 0);//create a variable to process vector_Size by  vector CH size (256) times the int size 
		vector<int> NCH(256, 0);//create a variable to process vector_Size by  vector NCH size (256) times the int size 

		//Norm constant declares the images size at 255
		float norm_constant = image_input.size();
		norm_constant = 255 / norm_constant;

		//declaration of local size
		size_t local_size = 10;

		//Create buffers 
		cl::Buffer dev_image_input(context, CL_MEM_READ_ONLY, image_input.size()); //READ ONLY the input image by creating dev_image_input buffer
		cl::Buffer dev_image_output(context, CL_MEM_READ_WRITE, image_input.size()); //READ & WRITE  the input image by creating dev_image_output buffer
		cl::Buffer buffer_H(context, CL_MEM_READ_WRITE, vector_Size); //READ & WRITE 
		cl::Buffer buffer_CH(context, CL_MEM_READ_WRITE, vector_Size); //READ & WRITE 
		cl::Buffer buffer_NCH(context, CL_MEM_READ_WRITE, vector_Size); //READ & WRITE 
		cl::Buffer Buffer_LUT(context, CL_MEM_READ_WRITE, vector_Size);

		//enqueueWriteBuffer inorder to write to buffer created for histograms object from host memory. 
		queue.enqueueWriteBuffer(dev_image_input, CL_TRUE, 0, image_input.size(), &image_input.data()[0]);
		queue.enqueueWriteBuffer(buffer_H, CL_TRUE, 0, vector_Size, &H[0]); //buffer for intensity histogram
		queue.enqueueWriteBuffer(buffer_CH, CL_TRUE, 0, vector_Size, &CH[0]);//buffer for cumulative histogram
		queue.enqueueWriteBuffer(Buffer_LUT, CL_TRUE, 0, vector_Size, &NCH[0]); //buffer for LUT
		typedef int mytype;

		///// Intensity Histogram Kernels ////////////////
		cl::Kernel kernelHistogram = cl::Kernel(program, "int_histogram");
		kernelHistogram.setArg(0, dev_image_input);		//hist_simple refers to intensity histogram kernel in mykernels.cl
		kernelHistogram.setArg(1, dev_image_output);		//the following is the set arguments. Here there are 4 arguments
		kernelHistogram.setArg(2, buffer_H); 		//First argument to process input image
		kernelHistogram.setArg(3, 0); 		//Second - process output image
		kernelHistogram.setArg(4, 255); 	//Third & Fourth - arguments containing vector sizes

		///// Cumulative Histogram Kernels ////////////////
		cl::Kernel kernelcumHistogram = cl::Kernel(program, "cum_histogram");
		kernelcumHistogram.setArg(0, buffer_H);
		kernelcumHistogram.setArg(1, buffer_CH);


		///// Normalised Cumulative Histogram Kernels ////////////////
		cl::Kernel kernelcumNormHistogram = cl::Kernel(program, "cumNorm_histogram");
		kernelcumNormHistogram.setArg(0, buffer_H);
		kernelcumNormHistogram.setArg(1, buffer_NCH);
		kernelcumNormHistogram.setArg(2, cl::Local(vector_Size));
		kernelcumNormHistogram.setArg(3, cl::Local(vector_Size));
		kernelcumNormHistogram.setArg(4, norm_constant);//declaration of image constant as arguments

		///// Localised Hillis Steele kernel execution ////////////////
		cl::Kernel kernellocalHS = cl::Kernel(program, "local_hs");
		kernellocalHS.setArg(0, buffer_H);
		kernellocalHS.setArg(1, buffer_NCH);

		///// Globalised Hillis Steele kernel execution ////////////////
//		cl::Kernel kernelglobalHS = cl::Kernel(program, "global_hs");
//		kernelglobalHS.setArg(0, buffer_H);
//		kernelglobalHS.setArg(1, buffer_NCH);

		///// Globalised Blelloch kernel execution ////////////////
/*		cl::Kernel kernelcumNormHistogramBL = cl::Kernel(program, "global_bl");
		kernelcumNormHistogramBL.setArg(0, buffer_H);
		kernelcumNormHistogramBL.setArg(1, buffer_NCH);*/

		///// LUT kernel execution ////////////////
		cl::Kernel kernel_LUT = cl::Kernel(program, "LUT");
		kernel_LUT.setArg(0, dev_image_input);
		kernel_LUT.setArg(1, dev_image_output);
		kernel_LUT.setArg(2, buffer_NCH);//output image

		//enqueueNDRangeKernel is the offset, global size, and local size are fixed to 0, 1, and 1 respectively in a single dimension
		queue.enqueueNDRangeKernel(kernelHistogram, cl::NullRange, cl::NDRange(image_input.size()), cl::NullRange, NULL, &prof_event);
		queue.enqueueNDRangeKernel(kernelcumHistogram, cl::NullRange, cl::NDRange(vector_Size), cl::NullRange, NULL, &prof_event2);
		queue.enqueueNDRangeKernel(kernelcumNormHistogram, cl::NullRange, cl::NDRange(vector_Size), cl::NullRange, NULL, &prof_event3);
		queue.enqueueNDRangeKernel(kernel_LUT, cl::NullRange, cl::NDRange(image_input.size()), cl::NullRange, NULL, &prof_event4);

		vector<unsigned char> output_buffer(image_input.size());

		//enqueueReadBuffer:read from a buffer object to host memory
		queue.enqueueReadBuffer(dev_image_output, CL_TRUE, 0, output_buffer.size(), &output_buffer.data()[0]);
		queue.enqueueReadBuffer(buffer_H, CL_TRUE, 0, vector_Size, &H[0]);
		queue.enqueueReadBuffer(buffer_CH, CL_TRUE, 0, vector_Size, &CH[0]);
		queue.enqueueReadBuffer(buffer_NCH, CL_TRUE, 0, vector_Size, &NCH[0]);
		queue.enqueueReadBuffer(dev_image_output, CL_TRUE, 0, output_buffer.size(), &output_buffer.data()[0]);

		//Output execution times
		cout << "Intensity Histogram 8-bit" << H << "\n\n" << H.size() << endl;


		std::cout << "Kernel execution time [ns]:" <<
			prof_event.getProfilingInfo<CL_PROFILING_COMMAND_END>() -
			prof_event.getProfilingInfo<CL_PROFILING_COMMAND_START>() << std::endl << std::endl;
		cout << "\nKernel H info" << GetFullProfilingInfo(prof_event, ProfilingResolution::PROF_US) << endl;

		cout << "Cumulative Histogram 8-bit" << CH << "\n\n" << endl;

		cout << "The kernel execution time [ns]:" <<
			prof_event2.getProfilingInfo<CL_PROFILING_COMMAND_END>() -
			prof_event2.getProfilingInfo<CL_PROFILING_COMMAND_START>() << std::endl;
		std:cout << "\nKernel CH info" << GetFullProfilingInfo(prof_event2, ProfilingResolution::PROF_US) << endl;

		cout << "Normalised cumulative Histogram 8-bit" << NCH << "\n\n" << endl;

		std::cout << "The kernel execution time [ns]:" <<
			prof_event3.getProfilingInfo<CL_PROFILING_COMMAND_END>() -
			prof_event3.getProfilingInfo<CL_PROFILING_COMMAND_START>() << std::endl;
		cout << "\nKernel NCH info" << GetFullProfilingInfo(prof_event3, ProfilingResolution::PROF_US) << endl;



		CImg<unsigned char> output_image(output_buffer.data(), image_input.width(), image_input.height(), image_input.depth(), image_input.spectrum());
		CImgDisplay disp_output(output_image, "output");

		while (!disp_input.is_closed() && !disp_output.is_closed()
			&& !disp_input.is_keyESC() && !disp_output.is_keyESC()) {
			disp_input.wait(1);
			disp_output.wait(1);
		}
		//initialize bin numbers
		int number_bins = 255;

		//hist atomic
		cl::Kernel kernel1 = cl::Kernel(program, "hist_atomic");
		kernel1.setArg(0, dev_image_input);
		kernel1.setArg(1, dev_image_output);
		kernel1.setArg(2, cl::Local(local_size * sizeof(mytype)));//local memory size
		kernel1.setArg(3, number_bins);

	}
	catch (const cl::Error& err) {
		std::cerr << "ERROR: " << err.what() << ", " << getErrorString(err.err()) << std::endl;
	}
	catch (CImgException& err) {
		std::cerr << "ERROR: " << err.what() << std::endl;
	}

	return 0;
}









// EnqueueNDRangeKernel is the case where the offset, global size and local sizes are fixed.
//Here the EnqueueNDRangeKernel API call is made, the key three arguments are: 
//the kernel object that had been previously associated with kernel name: in this case kernelHistogram
//no. of work items that are required to be executed (global size)
//no of work items that are required to be work grouped (local size)






